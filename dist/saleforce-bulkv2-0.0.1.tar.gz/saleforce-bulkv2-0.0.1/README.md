# salesforce-bulkv2
salesforce Bulk Api 2.0 Utility Library
